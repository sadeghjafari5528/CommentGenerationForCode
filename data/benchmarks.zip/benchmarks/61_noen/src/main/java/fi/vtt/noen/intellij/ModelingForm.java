package fi.vtt.noen.intellij;

/**

 */
public class ModelingForm {
}
