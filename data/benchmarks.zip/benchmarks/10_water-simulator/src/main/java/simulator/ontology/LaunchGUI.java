package simulator.ontology;

import jade.content.AgentAction;

/** file: LaunchGUI.java
 * @author ontology bean generator
 * @version 2003/10/26
 */


public class LaunchGUI implements AgentAction{ 

}
