package simulator.ontology;

import jade.content.Concept;

/** file: WaterConsumption.java
 * @author ontology bean generator
 * @version 2003/08/12
 */


public class WaterConsumption implements Concept{ 

  // Float quantity
  private Float quantity;
  public void setQuantity(Float s) { this.quantity=s; }
  public Float getQuantity() { return this.quantity; }

}
