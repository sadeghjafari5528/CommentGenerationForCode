package simulator.ontology;

import jade.content.Concept;

/** file: StepAttr.java
 * @author ontology bean generator
 * @version 2003/08/12
 */


public class StepAttr implements Concept{ 

  // Integer id
  private Integer id;
  public void setId(Integer s) { this.id=s; }
  public Integer getId() { return this.id; }

}
